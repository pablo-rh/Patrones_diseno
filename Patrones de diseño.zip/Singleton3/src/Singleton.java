public final class Singleton {
	
	//static significa que ya estara iniciado en memoria
    private static volatile Singleton instance;

    public String value;

    private Singleton(String value) {
        this.value = value;
    }

    public static Singleton getInstance(String value) {
        Singleton result = instance; //lo compara con un inicio
        if (result != null) {
            return result;
        }
        synchronized(Singleton.class) {// evita que mas de un hilo pueda utilizar el sstema
            if (instance == null) {
                instance = new Singleton(value);
            }
            return instance;
        }
    }
}